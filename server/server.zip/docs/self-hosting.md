# MiroTalk SFU - Self Hosting

### How can I self-host MiroTalk SFU on my own server?

[https://docs.mirotalk.com/mirotalk-sfu/self-hosting/](https://docs.mirotalk.com/mirotalk-sfu/self-hosting/)

---
