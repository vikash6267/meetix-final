# MiroTalk RTMP Servers

![rtmp](./rtmpStreaming.jpeg)

### How to start the RTMP server?

[https://docs.mirotalk.com/mirotalk-sfu/rtmp/](https://docs.mirotalk.com/mirotalk-sfu/rtmp/)

---
